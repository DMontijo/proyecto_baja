<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AREA extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'AREAID'          => [
                'type'           => 'INT',
                'unsigned'       => TRUE,
                'auto_increment' => TRUE,
            ],
            'AREADESCR'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '200',
            ],
            'DEPENDEAREA'       => [
                'type'           => 'INT',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'OFICINAID'          => [
                'type'           => 'INT',
                'unsigned'       => TRUE,
            ],
            'EMPLEADOIDRESPONSABLEAREA'          => [
                'type'           => 'INT',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'RESPONSABLEDEOFICINA'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'AGENDARALASIGNAR'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'null' => TRUE,
            ],
        ]);
        $this->forge->addKey('AREAID', TRUE);
        $this->forge->addForeignKey('OFICINAID', 'OFICINA', 'OFICINAID');
        $this->forge->createTable('AREA');
    }

    public function down()
    {
        $this->forge->dropTable('AREA');
    }
}
