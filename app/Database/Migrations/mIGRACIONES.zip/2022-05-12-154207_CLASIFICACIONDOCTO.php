<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CLASIFICACIONDOCTO extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'CLASIFICACIONDOCTOID'          => [
                'type'           => 'INT',
                'unsigned'       => TRUE,
                'auto_increment' => TRUE
            ],
            'CLASIFICACIONDOCTODESCR'       => [
                'type'           => 'VARCHAR',
                'constraint'     => '200',
            ],
            'HOJA'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CLASIFICACIONDOCTOIDPADRE'          => [
                'type'           => 'INT',
                'unsigned'       => TRUE,
            ],
            'INSTITUCIONID'          => [
                'type'           => 'INT',
                'unsigned'       => TRUE,
            ],
            'AGENDAR'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'DOCUMENTOREMISION'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ENVIARBANDEJASALIDA'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CAPTURASENTENCIA'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CAPTURARECURSO'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ENVIARRECEPTORIA'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CAPTURACOMPUTOPENA'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'REGISTRABITACORADETENIDO'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'REGISTRALIBERADETENIDO'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ENVIARSOLICITUD'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ENVIARRESPUESTASOLICITUD'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CONCLUIRENAPELACION'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'REGISTRAORDENCAPTURA'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'RESUELVEIMPUTADO'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CAPTURACONVENIO'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'SOLICITAORDENINVESTIGACION'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'REGISTRASOLICITUDPERICIAL'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'TIPODOCUMENTO'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ACUMULACION'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ENVIAREVISIONSOLICITUD'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'MARCARTIPODETENCION'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CAPTURARDATOSCATEO'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CAPTURASEGUIMIENTONOTIFICACION'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CAPTURARFECHAPRESCRIPCION'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ACCESODEFENSOR'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'DETERMINACION'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'ENVIANOTIFICACIONSEJAP'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'CONTESTANOTIFICACIONUI'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'SELECCIONAUDIENCIAPREVIA'          => [
                'type'           => 'CHAR',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'DECLARACIONIMPUTADO'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],
            'DICTAMENPERICIAL'          => [
                'type'           => 'CHAR',
                'default' => 'N',
                'constraint'     => '1',
                'unsigned'       => TRUE,
                'null' => TRUE,
            ],

        ]);
        $this->forge->addKey('CLASIFICACIONDOCTOID', TRUE);
        /* $this->forge->addForeignKey('CLASIFICACIONDOCTOIDPADRE', '', '');
        $this->forge->addForeignKey('INSTITUCIONID', '', '');
         */$this->forge->createTable('CLASIFICACIONDOCTO');
    }

    public function down()
    {
        $this->forge->dropTable('CLASIFICACIONDOCTO');
    }
}
